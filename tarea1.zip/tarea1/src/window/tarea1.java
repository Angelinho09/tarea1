package window;

public class tarea1 {
    public static void main(String[] args) {
        body miVentana = new body();
        miVentana.setVisible(true);
    }
}