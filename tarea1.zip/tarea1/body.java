package window;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class body extends JFrame {

    private JLabel lblTitulo;
    private JLabel lblPregunta;
    private JLabel lblInstruccion;
    private JTextField txtNombre;
    private JButton btnSaludar;
    private JLabel lblResultado;

    public body() {

        this.setTitle("Ventana de saludo");
        this.setBounds(100, 100, 500, 400);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.getContentPane().setLayout(null);

        // 1 Etiqu SALUDO (Título)
        lblTitulo = new JLabel("SALUDO");
        lblTitulo.setBounds(30, 20, 300, 30);
        this.getContentPane().add(lblTitulo);

        // 2 Etiq ¿Cmo te llamas?
        lblPregunta = new JLabel("¿Como te llamas?");
        lblPregunta.setBounds(30, 60, 300, 30);
        this.getContentPane().add(lblPregunta);

        // 3 Etiq escribe tu nombre
        lblInstruccion = new JLabel("Escribe tu nombre:");
        lblInstruccion.setBounds(30, 100, 130, 30);
        this.getContentPane().add(lblInstruccion);

        // 4  entrada de texto para el usuario (JTextField)
        txtNombre = new JTextField();
        txtNombre.setBounds(170, 100, 250, 30);
        this.getContentPane().add(txtNombre);

        //button 
        btnSaludar = new JButton("SALUDAR");
        btnSaludar.setBounds(170, 150, 120, 40);
        this.getContentPane().add(btnSaludar);

        // etiqu resultado 
        lblResultado = new JLabel("");
        lblResultado.setBounds(30, 220, 400, 30);
        this.getContentPane().add(lblResultado);

        //accion de boton 
        btnSaludar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //obtenemos lo que el usuario escribio en la caja de texto
                String nombreIngresado = txtNombre.getText();

                // validamos que no este vacio y muestra  el saludo personalizado
                if (!nombreIngresado.isEmpty()) {
                    lblResultado.setText("Hola " + nombreIngresado + ", bienvenido.");
                } else {
                    lblResultado.setText("Por favor, escribe un nombre.");
                }
            }
        });
    }
}
